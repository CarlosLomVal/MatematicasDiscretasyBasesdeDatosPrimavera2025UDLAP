/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectoprimavera2025;
import java.util.*;

/**
 *
 * @author charl
 */
public class ProyectoPrimavera2025 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //usamos system para poder recibir datos del usuario
        
        System.out.print("Ingrese el edificio de origen (A-G): ");
        String origen = scanner.nextLine().toUpperCase();
        int inicio = Ruta.getIndex(origen);
        
        System.out.print("Ingrese el edificio de destino (A-G): ");
        String destino = scanner.nextLine().toUpperCase();
        int fin = Ruta.getIndex(destino);
        
        if(inicio == -1){ //hacemos un if por si en el nodo origen el ususario ingresa algo invalido
            System.out.println("Entrada invalida, use letras de A a G.");
        } else if(fin == -1){ //otro else if por si el usuario elige un nodo de destino invalido
            System.out.println("Entrada invalida, use letras de A a G.");
        } else{ //si elige una opcion valida creamos el grafo y ejecutamos el algoritmo dijkstra
            int[][] grafo = Ruta.Grafo();
            Ruta.dijkstra(grafo, inicio, fin);
        }
        
    }
}
