/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoprimavera2025;
import java.util.*;

/**
 *
 * @author charl
 */
public class Ruta {
    private static final int valorinicialC = Integer.MAX_VALUE; //incializamos el valor inicial de las conexiones como el valor más grande que puede tomar un entero, lo cual se hace cuando no hay una conexión entre dos nodos 
    private static final int n = 7; //inicializamos el valor de nuestros edificios o nodos
    //private static final String[] nombrenodos = {"A", "B", "C", "D", "E", "F", "G"}; //inicializamos un arreglo de strings para representar el nombre de los nodos
    private static final String[] nombrenodos = { //inicializamos un arreglo de strings para representar el nombre de los nodos 
        "A: Edificio de Humanidades",
        "B: Edificio de Ingenierias",
        "C: Auditorio Guillermo y Sofia Jenkins",
        "D: Edificio de Negocios",
        "E: Biblioteca",
        "F: Cafeteria",
        "G: Edificio de Medicina"
    };
    
    public static int getIndex(String nombre){ //construimos el metodo para poder ver si lo ingresado por el usuario esta contenido en el arreglo que tiene los nombres de los nodos 
        for(int i=0; i<nombrenodos.length; i++){ //for para recorrer el arreglo y buscar la coincidencia
            if(nombrenodos[i].equalsIgnoreCase(nombre)){ //comparamos el nodo sin identificar mayusculas o minusculas
                return i; //retornamos la posicion del arreglo
            }
        }
        return -1; //de lo contrario se da un -1
    }
    
    public static int[][] Grafo(){ //metodo para hacer nuestro grafo
        int[][] grafo=new int[n][n]; //realizamos la matriz de adyacencia nxn 
        
        for(int i=0; i<grafo.length; i++){ //ejecutamos un for anidado para recorrer tanto las columnas como las filas de la matriz
            for(int j=0; j<grafo[i].length; j++){
                grafo[i][j] = valorinicialC; //asignando o indicando que lo nodos no tienencomo tal una conexion
            }
        }
        
        int[][] nodos={ //creamos y rellenamos un arreglo de arreglos que representa las distancias entre los nodos 
            {0, 1, 200}, {0, 2, 300},
            {1, 6, 600},
            {2, 5, 300}, 
            {3, 4, 100}, {3, 6, 300},
            {4, 5, 200},
        };
        
        for(int i=0; i<nodos.length; i++){ //realizamos un for para añadir a la matriz adyacencia los datos de las distancias (aristas)
            int[] conexiones = nodos[i];  //dependiendo la iteracion guardamos la conexion entre nodos correspondiente
            grafo[conexiones[0]][conexiones[1]] = conexiones[2];
            grafo[conexiones[1]][conexiones[0]] = conexiones[2]; //como el grafo no es dirigido se realiza en ambas direcciones
        }
        
        return grafo;
    }
    
    public static void dijkstra(int[][] grafo, int inicio, int fin){ //realizamos el metodo con el algoritmo dijkstra para encontrar la ruta mas rapida
        int[] distancia = new int[n]; //guardamos las distnacias  desde el nodo de inicio hasta cada uno de los demas
        boolean[] nodovisitado = new boolean[n]; //realizamos un arreglo de tipo booleano para saber si un nodo ya se visito en la ruta
        int[] nodoprevio = new int[n]; //guardamos el nodo previo a cada avance, para poder reconstruir el camino al final
        Arrays.fill(distancia, valorinicialC); //inicialmente llenamos el arreglo de distancia con conexiones "vacias o nulas"
        Arrays.fill(nodoprevio, -1); //incializamos el arreglo de nodos previos en -1 indicando que el nodo n el que se inicia no tiene predecesor
        distancia[inicio] = 0; //inicializamos la distancia del nodo de inicio en 0
        
        for(int i=0; i<n-1; i++){ //hacemos un for para encontrar los nodos (de los que no se han visitado) que más cerca están
            int d= -1; //inicializamos el indice del nodo con menordistancia en -1 (no se han encontrado en un incio)
            for(int j=0; j<n; j++){ //for anidado para recorrer todos los nodos
                if(!nodovisitado[j] && (d == -1 || distancia[j] < distancia[d])){ //si el nodo no se ha visitado y tiene la distancia mas baja (j mas cerca del inciio que d) 
                    d = j; //d se convierte en el nodo mas cercano 
                }
            }
            
            if(distancia[d] == valorinicialC){ //si la distancia es nula o no hay conexion posible se rompe el ciclo
                break;
            }
            nodovisitado[d] = true; //sino seguimos y marcamos el nodo más cercano como ya visitado
            
            for(int k=0; k<n; k++){ //se recorren los vecinos del nodo d 
                if (grafo[d][k] != valorinicialC && distancia[d] + grafo[d][k] < distancia[k]){ //si existe conexion entre el vecino y d, a la vez que, se ecnuentra que la ruta desde el nodo inicial es más corta que el camino conocido
                    distancia[k] = distancia[d] + grafo[d][k]; //se catucaliza la nueva disctancia corta 
                    nodoprevio[k] = d; //se idnica que el nodo previo al nuevo nodo alcanzado es d
                }
            }
        }
        
        if(distancia[fin] == valorinicialC){ //si la distancia hacia el nodo destino, para este punto, todavia no se alcanza 
            System.out.println("No hay ruta disponible."); //significa que no hay ruta
        }
        
        List<String> caminoCorto = new ArrayList<>(); //creamos una lista vacia para reconstruir el camino mas corto formulado
        for(int at = fin; at != -1; at = nodoprevio[at]){ //recorremos desde el nodo de destino hasta el nodo de origen, añadiendo descendentemente los nombres de los nodos a la lista
            caminoCorto.add(nombrenodos[at]); //agregamos el nombre y terminamos hasta que lleguemos al predecesor del origen (-1)
        }
        Collections.reverse(caminoCorto); //invertimos la lista para que este derecha al mostrarla 
        
        System.out.println("Ruta mas corta: " + String.join(" -> ", caminoCorto)); //imprimimos la ruta mas corta
        System.out.println("Distancia total: " + distancia[fin] + " metros"); //mostramos la distancia en metros entre el nodo de origen y el de destino
        
    }
    
}
